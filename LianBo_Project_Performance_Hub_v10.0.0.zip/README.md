# Lianbo Project Performance Hub

Complete replacement package — version `v10.0.0` (visual redesign, built on v9.9.1).

This package keeps the existing Google Sheets databases and application functions. Replacing the GitHub code does not delete Google Sheets records.

## What is included

- Main Streamlit application with KPI, Work Tickets/Kanban, BN, OEE, Line Verification and Admin modules.
- OEE input by exact shift: `1st shift (06:00-14:00)`, `2nd shift (14:00-22:00)`, `3rd shift (22:00-06:00)` or `All shifts`.
- When `All shifts` is selected, the app opens a horizontal multi-select for `1st`, `2nd`, `3rd`. Choose two or all three; Open time and Target are calculated from the selected shifts. The selection is stored in `OEE_input / Included_Shifts`.
- Daily/weekly/monthly/yearly OEE is calculated from summed raw shift data, not from an average of shift percentages.
- Per-user View/Edit overrides for every main application tab, independent of the user's role.
- Per-user e-mail notification switches for tasks, reminders, missing work time and BN alerts.
- `Technician_ID` as the primary link between Users, Technicians, Tasks and Task Activity.
- Technician-only Work Ticket visibility; admins/managers retain full access. Completed Kanban cards show task Start and Finish timestamps next to the duration information.
- Central Google Sheets cache, rate limiting, retry and stale-data fallback.
- Central SMTP service and `EMAIL_LOG` audit worksheet.
- Automatic weekday checks:
  - missing work-time alert for the previous workday after 11:00 Europe/Belgrade;
  - missing BN alert after 11:00 Europe/Belgrade;
  - one BN deviation summary 15 minutes after the latest BN entry;
  - one daily reminder for every task that is not Closed/Completed.
- GitHub Actions workflow that wakes a sleeping Streamlit app and clicks the Streamlit wake prompt when necessary.
- Turbo startup: normal users do not wait for ALL_ACTIVITIES/BN synchronization or scheduled notification checks; these run through the dedicated `?automation=1` background route.

## Clean GitHub replacement

Do not delete the GitHub repository itself. Delete/replace only its files. Deleting the repository also deletes the `STREAMLIT_APP_URL` Action secret and can break the existing Streamlit deployment connection.

1. Extract `LianBo_Project_Performance_Hub_v10.0.0.zip` on the computer.
2. Open the existing GitHub repository on branch `main`.
3. Remove the old repository files, but keep the repository itself.
4. Choose **Add file -> Upload files**.
5. Drag the extracted repository contents. Do not upload the ZIP itself and do not add an extra outer folder.
6. Confirm that `.github/workflows/wake_streamlit.yml` exists in exactly that path.
7. Commit directly to `main`.

The repository root must contain `lianbo_project_performance_hub.py`, `requirements.txt`,
the `static/` folder (background picture) and `.streamlit/config.toml`
(enables static file serving; without it the app still works, only the
background picture is not shown).

## Streamlit Community Cloud

- Main file path: `lianbo_project_performance_hub.py`
- Branch: `main`
- Keep the existing Streamlit Secrets. Use `.streamlit/secrets.toml.example` only as a field-name reference.
- Never upload a real `service_account.json`, Gmail password or `secrets.toml` to GitHub.

The optional `project_department.jpg` background is no longer required. If it is absent, the app automatically uses its built-in dark gradient background.

## Required GitHub Actions secret

In the GitHub repository open:

`Settings -> Secrets and variables -> Actions -> New repository secret`

Create or verify:

- Name: `STREAMLIT_APP_URL`
- Value: the complete deployed Streamlit application URL beginning with `https://`

Optional security hardening: set the same `AUTOMATION_TOKEN` value in GitHub Actions secrets **and** Streamlit Secrets. If it is configured in Streamlit, the background route requires that token (the workflow now passes it). Without a token the background route still runs (earlier versions silently skipped all background work when the token was missing).

Then open `Actions -> Wake Streamlit and run alerts -> Run workflow` once manually. A successful run should be green and will upload a short-lived diagnostic screenshot artifact.

## Notification setup inside the application

Both the `Technicians` worksheet and the Administration user form can control notification delivery. The Administration form stores these per-user fields in `User&Password`:

- `Email`
- `Receive_Task_Email`
- `Receive_Task_Reminder`
- `Receive_Missing_Time_Email`
- `Receive_BN_Email`
- `Supervisor`
- `Active`

Only active people whose applicable notification flag is `YES` receive that alert. A person marked `Supervisor=YES` can receive selected alerts but is excluded from missing-time checks and evaluation penalties.

The same user row also stores `View_*` and `Edit_*` columns for Work Tickets, KPI Process, Bottleneck, OEE, Line Verification and Administration. Blank means `Role default`; `YES` and `NO` are individual overrides.

All delivery attempts are recorded in the `EMAIL_LOG` worksheet. Use the Admin/Alerts manual-check buttons for an immediate test.

## v9.9.0 changes (why entries sometimes looked missing)

- KPI now imports new Google Forms, Work Ticket and downtime entries by itself (at most every 2 minutes, immediately after a Work Ticket save). Before, the import ran only through the background automation, which never ran: it required `AUTOMATION_TOKEN` and the workflow did not pass it.
- Work Ticket date/time fields accept `23.10.2026.`, `23. 10. 2026.`, `23/10/2026`, `23.10.26`, `8.30`, `8h30`, `830`; an empty End Date means the same day. Earlier a trailing dot or a missing End Date rejected a correct entry.
- Mixed time formats (`08:30`, `8:30:00`) no longer remove rows from KPI.
- Names are matched independent of word order, case and diacritics (`Nikolić Bojan` = `Bojan Nikolic`, `Đorđe` = `Djordje`), and KPI always shows the official technician name.
- Sheet columns are matched independent of spelling (`Assigned To` = `Assigned_To`); text starting with `-`, `+`, `=` is no longer stored as `#ERROR!`; appends are anchored at column A.
- Forms keep the typed values when an entry is rejected; double taps on Save do not create duplicates; a failed follow-up step (e-mail, ENVA) never hides a saved entry.
- Google Sheets engine: real quota limiter (no fixed 0.35 s wait before every request), live reads for duplicate checks and row updates, stale data only after all retries and with a visible warning.
- BN Forms: decimal comma (`12,5`) accepted, dates detected per sheet locale, duplicate check by real date. Line Verification dates are no longer swapped/dropped.
- Missing-work alert is sent only after a successful synchronization (no false alarms) and never twice.
- Period OEE again uses daily-capped components (v9.4.9 rule).
- Background picture served as a static file (was re-sent with every click).

Run the checks locally:

```
python -m unittest discover -s tests -p "test_*.py"
python tests/simulation/run_simulation.py
```

## Important

- The workflow runs every 15 minutes on weekdays during the configured UTC window.
- GitHub may temporarily delay scheduled workflows; the manual **Run workflow** button remains available.
- The first Google Sheets load can be slower. Repeated navigation uses the shared cache.
- Existing Sheets and their data must not be renamed or deleted.
